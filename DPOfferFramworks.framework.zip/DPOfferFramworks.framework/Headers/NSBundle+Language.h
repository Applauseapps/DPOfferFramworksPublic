#import <Foundation/Foundation.h>

@interface NSBundle (Language)

+(void)setLanguage:(NSString*)language;

@end
